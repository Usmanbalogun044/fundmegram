/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'bg', {
	alt: 'Алтернативен текст',
	btnUpload: 'Изпрати на сървъра',
	captioned: 'Надписано изображение',
	captionPlaceholder: 'Надпис',
	infoTab: 'Изображение',
	lockRatio: 'Заключване на съотношението',
	menu: 'Настройки на изображението',
	pathName: 'изображение',
	pathNameCaption: 'надпис',
	resetSize: 'Нулиране на размер',
	resizer: 'Кликни и влачи, за да преоразмериш',
	title: 'Настройки на изображението',
	uploadTab: 'Качване',
	urlMissing: 'URL адреса на изображението липсва.',
	altMissing: 'Липсва алтернативен текст.'
} );
