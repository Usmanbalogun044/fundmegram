<?php

return array(

    /*
    |--------------------------------------------------------------------------
    | Facebook App ID
    |--------------------------------------------------------------------------
    | Create your app on https://developers.facebook.com/
	|
    */

     //<--- Facebook App ID
    'id' => "APP_ID",

	//<--- Language - Check available languages --->  https://github.com/akarve/facebook-locales-to-json/blob/master/data/FacebookLocales.xml
    'lang' => "en_US",

);
