<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Slider Language Lines
    |--------------------------------------------------------------------------
    |
    */

    'slider_1_title' => 'Little help, for big cause!',
    'slider_1_subtitle' => 'Cras justo odio, dapibus ac facilisis in, egestas eget quam.',

    'slider_2_title' => 'Help people near your',
    'slider_2_subtitle' => 'Cras justo odio, dapibus ac facilisis in, egestas eget quam. Donec id.',

    'slider_3_title' => 'Educating the future',
    'slider_3_subtitle' => 'With a small contribution you can help educate hundreds of children.',





];
